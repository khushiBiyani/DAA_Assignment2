import random
import networkx as nx

# Define the sizes of the two sets of nodes
n1 = 100  # Number of nodes in set 1
n2 = 70  # Number of nodes in set 2

# Define the probability of an edge between nodes in set 1 and set 2
p = 0.25

# Create an empty bipartite graph
G = nx.Graph()

# Add nodes to the graph, with different node colors based on their set membership
G.add_nodes_from(range(1, n1+1), bipartite=0)  # Set 1 nodes
G.add_nodes_from(range(n1+1, n1+n2+1), bipartite=1)  # Set 2 nodes

# Add edges to the graph
for i in range(1, n1+1):
    for j in range(n1+1, n1+n2+1):
        if random.random() < p:
            G.add_edge(i, j)

# Write the output to a file
with open('bipartite_graphs.txt', 'w') as f:
    # Print the input format
    print(n1+n2, G.number_of_edges(), sep=' ', file=f)  # Total vertices and total edges
    for edge in G.edges():
        print(*edge, file=f)  # Edges as space-separated node names
    print(n1, n2, file=f)  # Sizes of the two sets of nodes
    print(*range(1, n1+1), file=f)  # Node names in set 1
    print(*range(n1+1, n1+n2+1), file=f)  # Node names in set 2
