var searchData=
[
  ['task1_262_2ecpp_19',['task1&amp;2.cpp',['../task1_62_8cpp.html',1,'']]]
];
