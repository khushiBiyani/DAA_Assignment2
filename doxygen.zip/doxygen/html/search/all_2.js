var searchData=
[
  ['calculateerror_5',['calculateError',['../SegLeastSq_8cpp.html#a3676ea7343878c80417f0286bf77f708',1,'SegLeastSq.cpp']]],
  ['calculateopt_6',['calculateOpt',['../SegLeastSq_8cpp.html#a57aeb552a92184b5bd748a6a05c48d40',1,'SegLeastSq.cpp']]],
  ['createpoints_2epy_7',['createPoints.py',['../createPoints_8py.html',1,'']]]
];
