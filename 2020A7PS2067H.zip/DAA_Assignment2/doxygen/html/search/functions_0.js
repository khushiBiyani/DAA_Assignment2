var searchData=
[
  ['add_5fbackedge_28',['add_backedge',['../bipartite_8cpp.html#a4ac7595dea780fb16d78ef51c360fb1c',1,'add_backedge(vector&lt; edge &gt; &amp;edges, int u, int v, int b):&#160;bipartite.cpp'],['../task1_62_8cpp.html#a4ac7595dea780fb16d78ef51c360fb1c',1,'add_backedge(vector&lt; edge &gt; &amp;edges, int u, int v, int b):&#160;task1&amp;2.cpp']]],
  ['augment_5fpath_29',['augment_path',['../bipartite_8cpp.html#ac038cd779fef3b891b68d6e445e7f50b',1,'augment_path(vector&lt; edge &gt; &amp;residual, int source, int sink, vector&lt; int &gt; &amp;parent):&#160;bipartite.cpp'],['../task1_62_8cpp.html#ac038cd779fef3b891b68d6e445e7f50b',1,'augment_path(vector&lt; edge &gt; &amp;residual, int source, int sink, vector&lt; int &gt; &amp;parent):&#160;task1&amp;2.cpp']]]
];
