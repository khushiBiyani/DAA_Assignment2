var searchData=
[
  ['calculateerror_32',['calculateError',['../SegLeastSq_8cpp.html#a3676ea7343878c80417f0286bf77f708',1,'SegLeastSq.cpp']]],
  ['calculateopt_33',['calculateOpt',['../SegLeastSq_8cpp.html#a57aeb552a92184b5bd748a6a05c48d40',1,'SegLeastSq.cpp']]]
];
